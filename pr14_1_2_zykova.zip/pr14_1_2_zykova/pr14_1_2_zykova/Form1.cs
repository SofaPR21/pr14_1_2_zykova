﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace pr14_1_2_zykova
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //получаем n из NumericUpDown
            int n = (int)numericUpDown1.Value;
            Stack<int> numbers = new Stack<int>();

            //заполняем Stack числами от 1 до n
            for (int i = 1; i <= n; i++)
            {
                numbers.Push(i);
            }

            //очищаем ListBox перед выводом
            listBox1.Items.Clear();

            listBox1.Items.Add("n = " + numbers.Count);
            listBox1.Items.Add("Размерность стека = " + numbers.Count);
            listBox1.Items.Add("Верхний элемент стека = " + numbers.Count);

            string str = "";

            //элементы из стека добавляем в ListBox
            while (numbers.Count > 0)
            {
                str += numbers.Pop() + " ";
            }

            listBox1.Items.Add("Содержимое стека = " + str.Trim());

            numbers.Clear();

            listBox1.Items.Add("Новая резмерность стека = " + numbers.Count);
        }

        private string filepath = "t.txt";
        private void button2_Click(object sender, EventArgs e)
        {
            int count_1 = 0, count_2 = 0;

            if (File.Exists("t.txt"))
            {
                StreamReader writer = new StreamReader("t.txt");

                string expression = writer.ReadLine();

                foreach (char z in expression)
                {
                    if (z == ')') count_1++;
                    else if (z == '(') count_2++;
                }

                if (count_1 == count_2)
                {
                    listBox2.Items.Add($"В выражениии {expression} скобки сбалансированы");
                }
                else if (count_1 > count_2)
                {
                    listBox2.Items.Add($"В выражениии {expression} скобки не сбалансированы.");
                    listBox2.Items.Add($"Лишняя скобка ) на позиции  {expression.LastIndexOf(")")}");
                    StreamWriter new_ur = new StreamWriter("t1.txt");
                    new_ur.WriteLine("(" + expression);
                    new_ur.Close();
                }
                else
                {
                    listBox2.Items.Add($"В выражениии {expression} скобки не сбалансированы.");
                    listBox2.Items.Add($"Лишняя скобка ( на позиции  {expression.IndexOf("(")}");
                    StreamWriter new_ur = new StreamWriter("t1.txt");
                    new_ur.WriteLine(expression + ")");
                    new_ur.Close();
                }

            }
            else
                MessageBox.Show("Файл 't.txt'не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}

